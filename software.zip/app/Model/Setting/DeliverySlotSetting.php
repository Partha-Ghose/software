<?php

namespace App\Model\Setting;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliverySlotSetting extends Model
{
    use HasFactory;
}

<?php

namespace App\Model\Setting;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeliveryTimeSLot extends Model
{
    use HasFactory;
}
